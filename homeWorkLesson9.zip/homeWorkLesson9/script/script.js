const form = document.querySelector('#add_form');

let data = [];




form.addEventListener('submit', (event) =>{
    event.preventDefault();
    data.push(
        {
        title: event.target.title.value,
        photo: event.target.photo.value    

        }
    );
    rerender();
    event.target.title.value = '';
    event.target.photo.value = '';
}
)

function addCard (title, photo){
    const container = document.createElement('div');
    container.classList.add('card');

    const new_p = document.createElement('p');
    new_p.innerText = title;
    const pic = document.createElement('img');
    pic.src = photo;
    
    container.append(pic, new_p);
    return container;
};

function rerender(){
    const client = document.querySelector('#card_container');
    client.innerText='';

    if (data.length === 0){
        const p_1 = document.createElement('p');
        p_1.innerText = 'Нет клиентов';
        client.append(p_1);
    }else {
        for (let i = 0; i<data.length; i++){
            const card = addCard(data[i].title, data[i].photo);
            client.append(card);
        }
    }
};

rerender();